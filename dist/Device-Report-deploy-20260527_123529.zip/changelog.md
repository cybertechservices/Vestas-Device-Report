# Changelog

All notable changes to the Vestas Report Generator are recorded here.
Versioning: `x.y.z` — `y` = features, `z` = patches (per CLAUDE.md Working Rule #4).

## [1.3.2] — 2026-05-27

### Docs
- Expanded `DEPLOYMENT.md` into a full target-machine deployment runbook: the
  Tier A / Tier B decision (Node/Playwright only needed for menu option 6),
  prerequisite + network checks, the Mark-of-the-Web `Unblock-File` step and
  execution-policy guidance, credential setup, first-run verification,
  unattended/scheduled-task setup via `-EndpointIndex`, a troubleshooting table
  keyed to the script's real exit codes, and uninstall steps.

## [1.3.1] — 2026-05-27

### Fixed
- Corrected the operator-facing script name: the interactive menu header and the
  `.SYNOPSIS`/`.EXAMPLE` block now read `Device-Reports.ps1` (was the stale
  `Get-UnknownDevices.ps1`) — `Device-Reports.ps1:43, :46, :186`.

### Removed
- Deleted the orphaned `Get-NcmDeviceMapFromPage` function (~107 lines, zero call
  sites — the config-backup chain uses the Node/Playwright extractor
  `Get-NcmDeviceMapViaBrowser`). `Build-NcmSubconfigUrl` was verified LIVE (called
  by the chain at `Device-Reports.ps1:2084`) and left intact.

### Docs
- `requirements.md` FR8 counters and status markers updated to match the code:
  `cfgNoCombos` / `cfgNoHasChanges` (was the pre-rewrite `cfgEmpty`), corrected
  the `Chain complete:` summary line and the `Status` diagnostic markers.

## [1.3.0] — 2026-05-27

### Removed
- Dropped the three `DIAGNOSTIC:` endpoints from `conf\conf.json` (former menu
  options 7, 8, 9): `diagnostic-ncm-bulk-pp5750`,
  `diagnostic-device-asset-status-5750`, `diagnostic-ncm-subconfig-36070`.
  These were development/debugging probes with no code references; removal is a
  pure-data change (menu and dispatch are driven by array position + the `chain`
  property, never by slug or fixed index). The menu now lists 6 endpoints.

### Housekeeping
- Purged leftover dev/debug clutter that must not be deployed: stale `*.bak-*`
  copies of the script/config/JS, `tools\debug-*.png` screenshots,
  `tools\test-cookies.json` (a replayable SAML session), `tools\test-map.json`,
  `tools\ncm-map.log`, `log\ncm-page-debug-*.html` (CSRF token + authed page
  dump), and the empty root `package-lock.json` stub.
- Aligned version across `conf\conf.json`, `CLAUDE.md`, and
  `specs\requirements.md` to `1.3.0` (previously drifted: 1.2.2 / 1.2.0 / 1.2.0).
- Added this `changelog.md` (Working Rule #5) and a `conf\.env.example` template.
- Added `DEPLOYMENT.md` with two-tier install instructions for moving the tool
  to another Windows computer.

### Notes / known follow-ups (not changed in this release)
- The interactive menu header and the script `.SYNOPSIS` still print the old
  name `Get-UnknownDevices.ps1` (`Device-Reports.ps1:186`, `:43`, `:46`); the
  real entry point is `Device-Reports.ps1`.
- `Get-NcmDeviceMapFromPage` (`Device-Reports.ps1:796`) is orphaned dead code —
  the config-backup chain now uses the Node/Playwright path.
- `requirements.md` FR8 still documents the pre-rewrite counter names
  (`cfgEmpty`) and status strings; the code uses
  `cfgNoCombos` / `cfgNoHasChanges`.
